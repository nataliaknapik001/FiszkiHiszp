
package fiszkihiszp;


public class FiszkiHiszp {

    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
